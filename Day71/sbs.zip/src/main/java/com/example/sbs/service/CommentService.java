package com.example.sbs.service;

import com.example.sbs.Dto.CommentDto;
import com.example.sbs.Entity.Article;
import com.example.sbs.Entity.Comment;
import com.example.sbs.Repository.ArticleRepository;
import com.example.sbs.Repository.CommentRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CommentService {
    @Autowired
    private CommentRepository commentRepository;
    @Autowired
    private ArticleRepository articleRepository;

    public List<CommentDto> comments(Long articleId){
        return commentRepository.findByArticleId(articleId)
                .stream()
                .map(comment -> CommentDto.createCommentDto(comment))
                .collect(Collectors.toList());
    }

    @Transactional
    public CommentDto create(Long articleId, CommentDto dto){
        Article article = articleRepository.findById(articleId)
                .orElseThrow(() -> new IllegalArgumentException("댓글 생성에 실패 하였습니다"));
        Comment comment = Comment.createComment(dto, article);
        Comment created = commentRepository.save(comment);
        return CommentDto.createCommentDto(created);
    }

    @Transactional
    public CommentDto update(Long id, CommentDto dto){
        Comment target = commentRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("댓글 생성에 실패 하였습니다. 대상 댓글이 없습니다"));
        target.patch(dto);
        Comment update = commentRepository.save(target);
        return CommentDto.createCommentDto(update);
    }

    public CommentDto delete(Long id){
        Comment target = commentRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("댓글을 삭제하는데 실패 하였습니다"));
        commentRepository.delete(target);
        return CommentDto.createCommentDto(target);
    }
}
