package com.example.sbs.Entity;

import com.example.sbs.Dto.CommentDto;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Getter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Comment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
//    부모게시글관련 기사하나에 여러개의 댓글
    @ManyToOne
//    외래키
    @JoinColumn(name = "article_id")
    private Article article;
    @Column
    private String nickname;
    @Column
    private String boby;

    public static Comment createComment(CommentDto dto, Article article){
        if (dto.getId() != null)
            throw new IllegalArgumentException("댓글 생성에 실패 하였습니다. 댓글의 ID가 없어야 합니다");
        if (dto.getArticleid() != article.getId())
            throw new IllegalArgumentException("댓글 생성에 실패 하였습니다. 게시글의 ID가 잘못 되었습니다");
        return new Comment(
                dto.getId(), article, dto.getNickname(), dto.getBody()
        );
    }

    public void patch(CommentDto dto){
        if (this.id != dto.getId()){
            throw new IllegalArgumentException("댓글 수정에 실패 하였습니다. 대상이 되는 댓글이 없습니다");
        }
        if (dto.getNickname() != null){
            this.nickname = dto.getNickname();
        }
        if (dto.getBody() != null){
            this.boby = dto.getBody();
        }
    }
}
